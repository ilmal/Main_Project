import time
import schedule
import shutil
import zipfile
import os
from datetime import datetime

target_folder = "/mnt/k8s_storage/kubedata/"
destination_folder = "/home/nils/backup-k8s/"

mongo_pod_name = "mongo-0"

zipfile_output_name = "k8s-backupdata-" + datetime.now().strftime("%Y-%m-%d/%H:%M:%S") + ".zip"


def centralizeServerFiles(tf_setup, df_setup):
    print("target_folder: ", tf_setup)
    print("destination_folder: ", df_setup)

    for file in os.listdir(tf_setup):
        if file.startswith("mc-servers"):
            shutil.copytree(tf_setup + file, df_setup + "server-files/" + file)
            print("file " + file + " copied")

def getMongoDump(mongo_pod_name, df_setup):
    print("uploading file to container")
    os.system("kubectl cp -n mongo ./container_script.sh " + mongo_pod_name + ":/")
    print("file uploaded")
    os.system("kubectl exec -it " + mongo_pod_name + " -- bash container_script.sh")
    print("script executed")
    os.system("kubectl cp " + mongo_pod_name + ":/dump " + df_setup + "/mongo-files")
    print("dump file copied to destination folder")

def compressToZip(df_setup, zipfile_output_name):
    print("creating zip file: " + zipfile_output_name)
    shutil.make_archive(zipfile_output_name, 'zip')
    print("starting zip process")
    zip = zipfile.ZipFile(zipfile_output_name, "w")
    print("writing server-files")
    zip.write(df_setup + "server-files")
    print("writing mongofiles")
    zip.write(df_setup + "mongo-files")
    print("writing complete, exiting zip")
    zip.close()



def main(tf_setup, df_setup):  # tf=target_folder; df=destination_folder;

    # check if argument is passed at startup, if not case: set var to default path see at start of file
    if tf_setup == None:
        tf_setup = target_folder
    if df_setup == None:
        df_setup = destination_folder

    # check if destination is clear
    print("cheking if destination folder is clear")
    if(len(os.listdir(df_setup)) > 0):
        print("destination folder not clear, deleting files")
        shutil.rmtree(df_setup)

    centralizeServerFiles(tf_setup, df_setup)
    getMongoDump(mongo_pod_name, df_setup)
    compressToZip(df_setup, zipfile_output_name)

    # schedule.every(1).seconds.do(
    #     centralizeServerFiles, tf_setup, df_setup)

    # while 1:
    #     schedule.run_pending()
    #     time.sleep(1)
