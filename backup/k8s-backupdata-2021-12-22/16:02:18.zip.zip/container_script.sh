echo running script in container

mongodump

echo dumpfile created

echo exiting container

exit